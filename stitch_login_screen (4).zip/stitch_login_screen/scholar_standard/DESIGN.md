# Design System Document

## 1. Overview & Creative North Star: "The Intellectual Atelier"
This design system moves away from the rigid, boxy layouts of traditional administrative software. Our Creative North Star is **The Intellectual Atelier**—a space that feels as authoritative as a university library but as fluid and modern as a high-end digital gallery. 

To achieve this, we reject the "template" look. We favor **intentional asymmetry**, where large display typography creates an editorial anchor, and components are positioned with significant breathing room. We replace harsh structural lines with **tonal depth and layered surfaces**, ensuring the reservation process feels like a premium service rather than a bureaucratic chore.

---

## 2. Colors & Surface Philosophy
The palette is rooted in a deep, institutional Navy, but its application is light-handed and sophisticated.

### The "No-Line" Rule
**Explicit Instruction:** Designers are prohibited from using 1px solid borders to section off content. Boundaries must be defined solely through background color shifts or subtle tonal transitions. For example, a `surface-container-low` sidebar sitting against a `surface` background creates a clear but soft structural division without the "grid-trap" feel of lines.

### Surface Hierarchy & Nesting
Treat the UI as a series of physical layers—like stacked sheets of fine vellum.
*   **Base:** `surface` (#f8f9fa)
*   **Secondary Content:** `surface-container-low` (#f3f4f5)
*   **Primary Interactive Cards:** `surface-container-lowest` (#ffffff)
*   **Active/Pop-over Elements:** `surface-bright` (#f8f9fa) with glassmorphism.

### The "Glass & Gradient" Rule
To elevate the "out-of-the-box" Material feel, use **Glassmorphism** for floating navigation bars or modal overlays. Use a 70% opacity version of `surface-container-lowest` with a `backdrop-filter: blur(12px)`. 

**Signature Texture:** For primary CTAs and Hero sections, use a subtle linear gradient (135°) transitioning from `primary` (#000666) to `primary-container` (#1a237e). This adds a "lithographic" depth that flat hex codes cannot achieve.

---

## 3. Typography: Editorial Authority
We utilize **Inter** for its mathematical precision and neutral "voice."

*   **Display (lg/md/sm):** Used for landing headers and large numerical data (e.g., "Available Rooms"). Set with tight letter-spacing (-0.02em) to feel like a premium journal.
*   **Headline (lg/md/sm):** Reserved for section titles. Use `primary` color to anchor the eye.
*   **Title (lg/md/sm):** Used for card headings and sub-sections.
*   **Body (lg/md/sm):** The workhorse. Use `on-surface-variant` (#454652) for long-form text to reduce eye strain, reserving `on-surface` (#191c1d) for high-importance snippets.
*   **Labels:** Always uppercase with +0.05em tracking when used in buttons or small UI tags to maintain an "institutional" metadata feel.

---

## 4. Elevation & Depth: Tonal Layering
Traditional drop shadows are often too "heavy" for an academic environment. We use **Ambient Shadows** and **Tonal Stacking**.

*   **The Layering Principle:** Place a `surface-container-lowest` card on a `surface-container-low` background. This creates a natural "lift" through contrast rather than artificial shadows.
*   **Ambient Shadows:** When an element must float (like a dropdown), use a shadow with a 32px blur, 0% spread, and 6% opacity using the `primary` hue as the shadow tint. This mimics natural light passing through high-quality paper.
*   **The "Ghost Border" Fallback:** If a border is required for accessibility, use the `outline-variant` (#c6c5d4) at **15% opacity**. Never use a 100% opaque border.

---

## 5. Components

### Buttons
*   **Primary:** A gradient fill (`primary` to `primary-container`). Roundedness: `md` (0.375rem). Use `label-md` for text.
*   **Secondary:** No fill. `outline-variant` (Ghost Border) at 20% opacity. On hover, transition to `secondary-fixed` (#dee0ff) with 0.5s ease.
*   **Tertiary:** No border, no fill. Use `primary` text. On hover, apply a `secondary-container` (#8596ff) background at 10% opacity.

### Input Fields
*   **Style:** Minimalist. Use a `surface-container-low` background. No border. On focus, a 2px bottom-accent of `primary` appears. 
*   **Error State:** Use `error` (#ba1a1a) for text and a subtle `error-container` (#ffdad6) background wash.

### Cards & Reservation Slots
*   **Rule:** Forbid divider lines. 
*   **Layout:** Separate time slots or room details using `8` (2rem) or `10` (2.5rem) vertical spacing. Use a `surface-container-highest` (#e1e3e4) small vertical pill to indicate status (e.g., "Reserved") rather than a full-width bar.

### Custom Component: The Academic Timeline
A vertical reservation track using a 2px `outline-variant` (10% opacity) line, but only as a decorative guide. Interactive blocks "float" over it using `surface-container-lowest` and a soft ambient shadow.

---

## 6. Do’s and Don’ts

### Do:
*   **Embrace Whitespace:** Use the `16` (4rem) and `20` (5rem) spacing tokens to separate major functional blocks. Academic users need "quiet" interfaces to focus.
*   **Use Subtle Hovers:** When hovering over a list item, use `secondary-fixed` (#dee0ff) at a very low opacity (15%) to create a "ghost" highlight.
*   **Align to the Baseline:** Ensure all typography sits on a consistent vertical rhythm to maintain a sense of "trustworthy" organization.

### Don't:
*   **No "Pure" Black:** Never use #000000. Use `on-surface` (#191c1d) for the highest contrast.
*   **No Sharp Corners:** Avoid `none` or `sm` roundedness for large containers. Stick to `md` or `lg` to soften the institutional feel.
*   **No High-Contrast Dividers:** If a separator is needed, use a `1px` height `surface-container-high` block, not a dark line.